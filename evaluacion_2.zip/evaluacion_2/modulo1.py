class Usuario:
    def __init__(self, idUsuario, nombre, correo, passw, direccion, telefono):
        self.__idUsuario = idUsuario
        self.__nombre = nombre
        self.__correo = correo
        self.__passw = passw
        self.__direccion = direccion
        self.__telefono = telefono

    #getters

    def getIdUsuario(self):
        return self.__idUsuario
    def getNombre(self):
        return self.__nombre
    def getCorreo(self):
        return self.__correo
    def getPassw(self):
        return self.__passw
    def getDireccion(self):
        return self.__direccion
    def getTelefono(self):
        return self.__telefono

    #setters

    def setIdUsuario(self, newIdUsuario):
        self.__idUsuario = newIdUsuario
    def setNombre(self, newNombre):
        self.__nombre = newNombre
    def setCorreo(self, newCorreo):
        self.__correo = newCorreo
    def setPassw(self, newPassw):
        self.__passw = newPassw
    def setDireccion(self, newDireccion):
        self.__direccion = newDireccion
    def setTelefono(self, newTelefono):
        self.__telefono = newTelefono

class Empleado(Usuario):
    def __init__(self, idUsuario, nombre, correo, passw, direccion, telefono, idEmpleado, fechaContratacion, salario, cargo):
        super().__init__(idUsuario, nombre, correo, passw, direccion, telefono)
        self.__idEmpleado = idEmpleado
        self.__fechaContratacion = fechaContratacion
        self.__salario = salario
        self.__cargo = cargo
    #idEmpleado, fechaContratacion, salario, cargo

    #g

    def getIdEmpleado(self):
        return self.__idEmpleado
    def getFechaContratacion(self):
        return self.__fechaContratacion
    def getSalario(self):
        return self.__salario
    def getCargo(self):
        return self.__cargo

    #s

    def setIdEmpleado(self, newIdEmpleado):
        self.__idEmpleado = newIdEmpleado
    def setFechaContratacion(self, newFechaContratacion):
        self.__fechaContratacion = newFechaContratacion
    def setSalario(self, newSalario):
        self.__salario = newSalario
    def setCargo(self, newCargo):
        self.__cargo = newCargo

class Administrador(Empleado):
    def __init__(self, idUsuario, nombre, correo, passw, direccion, telefono, idEmpleado, fechaContratacion, salario, cargo, nivelAcceso):
        super().__init__(idUsuario, nombre, correo, passw, direccion, telefono, idEmpleado, fechaContratacion, salario, cargo)
        self.__nivelAcceso = nivelAcceso

    def getNivelAcceso(self):
        return self.__nivelAcceso

    def setNivelAcceso(self, newNivelAcceso):
        self.__nivelAcceso = newNivelAcceso

class gerente(Administrador):
    def __init__(self, idUsuario, nombre, correo, passw, direccion, telefono, idEmpleado, fechaContratacion, salario, cargo, nivelAcceso, gerenteVentas):
        super().__init__(idUsuario, nombre, correo, passw, direccion, telefono, idEmpleado, fechaContratacion, salario, cargo, nivelAcceso)
        self.__gerenteVentas = gerenteVentas

    def getGerenteVentas(self):
        return self.__gerenteVentas

    def setGerenteVentas(self, newGerenteVentas):
        self.__gerenteVentas = newGerenteVentas