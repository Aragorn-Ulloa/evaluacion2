from Model.Dao import DepartamentoDAO, EmpleadoDAO, ProyectoDAO, RegistroTiempoDAO
from Model.Dto import DepartamentoDTO, EmpleadoDTO, ProyectoDTO, RegistroTiempoDTO



# ---------------- CONTROL DEPARTAMENTO ----------------
class ControlDepartamento:
    def __init__(self):
        self.__dao = DepartamentoDAO()

    def getDepartamentos(self):
        departamentos = []
        deptoTupla = self.__dao.verDepartamentos()
        if deptoTupla:
            for obj in deptoTupla:
                departamentos.append(DepartamentoDTO(obj[0], obj[1], obj[2]))
        return departamentos

    def getDepartamento(self, id):
        fila = self.__dao.buscarDepartamento(id)
        if fila:
            return DepartamentoDTO(fila[0], fila[1], fila[2])
        return None

    def agregarDepartamentoControl(self, id, nombre, idGerente):
        dto = DepartamentoDTO(id, nombre, idGerente)
        return self.__dao.agregarDepartamento(dto)

    def eliminarDepartamentoControl(self, id):
        return self.__dao.eliminarDepartamento(id)

    def actualizarDepartamentoControl(self, id, nombre, idGerente):
        dto = DepartamentoDTO(id, nombre, idGerente)
        return self.__dao.actualizarDepartamento(dto)

    def existeDepartamento(self, id):
        return self.__dao.buscarDepartamento(id) is not None


# ---------------- CONTROL EMPLEADO ----------------
class ControlEmpleado:
    def __init__(self):
        self.__dao = EmpleadoDAO()

    def getEmpleados(self):
        empleados = []
        empleadosTupla = self.__dao.verEmpleados()
        if empleadosTupla:
            for obj in empleadosTupla:
                empleados.append(EmpleadoDTO(obj[0], obj[1], obj[2], obj[3]))
        return empleados

    def getEmpleado(self, id):
        fila = self.__dao.buscarEmpleado(id)
        if fila:
            return EmpleadoDTO(fila[0], fila[1], fila[2], fila[3])
        return None

    def agregarEmpleadoControl(self, id, nombre, correo, idDepto):
        dto = EmpleadoDTO(id, nombre, correo, idDepto)
        return self.__dao.agregarEmpleado(dto)

    def eliminarEmpleadoControl(self, id):
        dto = EmpleadoDTO(id, "", "", "")
        return self.__dao.eliminarEmpleado(dto)

    def actualizarEmpleadoControl(self, id, nombre, correo, idDepto):
        dto = EmpleadoDTO(id, nombre, correo, idDepto)
        return self.__dao.actualizarEmpleado(dto)

    def existeEmpleado(self, id):
        return self.__dao.buscarEmpleado(id) is not None


# ---------------- CONTROL PROYECTO ----------------
class ControlProyecto:
    def __init__(self):
        self.__dao = ProyectoDAO()

    def getProyectos(self):
        proyectos = []
        proyectosTupla = self.__dao.verProyectos()
        if proyectosTupla:
            for obj in proyectosTupla:
                proyectos.append(ProyectoDTO(obj[0], obj[1], obj[2]))
        return proyectos

    def getProyecto(self, id):
        fila = self.__dao.buscarProyecto(id)
        if fila:
            return ProyectoDTO(fila[0], fila[1], fila[2])
        return None

    def agregarProyectoControl(self, id, nombre, idDepto):
        dto = ProyectoDTO(id, nombre, idDepto)
        return self.__dao.agregarProyecto(dto)

    def eliminarProyectoControl(self, id):
        return self.__dao.eliminarProyecto(id)

    def actualizarProyectoControl(self, id, nombre, idDepto):
        dto = ProyectoDTO(id, nombre, idDepto)
        return self.__dao.actualizarProyecto(dto)

    def existeProyecto(self, id):
        return self.__dao.buscarProyecto(id) is not None


# ---------------- CONTROL REGISTRO TIEMPO ----------------
class ControlRegistroTiempo:
    def __init__(self):
        self.__dao = RegistroTiempoDAO()

    def getRegistros(self):
        registros = []
        registrosTupla = self.__dao.verRegistros()
        if registrosTupla:
            for obj in registrosTupla:
                registros.append(RegistroTiempoDTO(obj[0], obj[1], obj[2], obj[3]))
        return registros

    def getRegistro(self, id):
        fila = self.__dao.buscarRegistro(id)
        if fila:
            return RegistroTiempoDTO(fila[0], fila[1], fila[2], fila[3])
        return None

    def agregarRegistroControl(self, id, fecha, horas, descripcion):
        dto = RegistroTiempoDTO(id, fecha, horas, descripcion)
        return self.__dao.agregarRegistro(dto)

    def eliminarRegistroControl(self, id):
        return self.__dao.eliminarRegistro(id)

    def actualizarRegistroControl(self, id, fecha, horas, descripcion):
        dto = RegistroTiempoDTO(id, fecha, horas, descripcion)
        return self.__dao.actualizarRegistro(dto)

    def existeRegistro(self, id):
        return self.__dao.buscarRegistro(id) is not None