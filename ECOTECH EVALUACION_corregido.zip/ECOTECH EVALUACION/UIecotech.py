from Control.Control import ControlDepartamento, ControlEmpleado, ControlProyecto, ControlRegistroTiempo

class Interfaz:
    def __init__(self):
        self.__ctrlDepartamento = ControlDepartamento()
        self.__ctrlEmpleado = ControlEmpleado()
        self.__ctrlProyecto = ControlProyecto()
        self.__ctrlRegistro = ControlRegistroTiempo()

    def verDepartamentos(self):
        departamentos = self.__ctrlDepartamento.getDepartamentos()
        if departamentos:
            for d in departamentos:
                print("ID:", d.getIdDepartamento())
                print("Nombre:", d.getNombre())
                print("Gerente:", d.getIdGerente())
        else:
            print("No hay departamentos registrados")

    def buscarDepartamento(self):
        id = input("Ingrese el ID del Departamento: ")
        d = self.__ctrlDepartamento.getDepartamento(id)
        if d:
            print("ID:", d.getIdDepartamento())
            print("Nombre:", d.getNombre())
            print("Gerente:", d.getIdGerente())
        else:
            print("No existe un Departamento con ese ID")

    def agregarDepartamento(self):
        id = input("Ingrese el ID del Departamento: ")
        if not self.__ctrlDepartamento.existeDepartamento(id):
            nombre = input("Ingrese el Nombre: ")
            gerente = input("Ingrese el ID del Gerente: ")
            if self.__ctrlDepartamento.agregarDepartamentoControl(id, nombre, gerente):
                print("Departamento agregado con éxito")
        else:
            print("Ya existe un Departamento con ese ID")

    def eliminarDepartamento(self):
        id = input("Ingrese el ID del Departamento: ")
        if self.__ctrlDepartamento.existeDepartamento(id):
            if self.__ctrlDepartamento.eliminarDepartamentoControl(id):
                print("Departamento eliminado con éxito")
        else:
            print("No existe un Departamento con ese ID")

    def actualizarDepartamento(self):
        id = input("Ingrese el ID del Departamento: ")
        if self.__ctrlDepartamento.existeDepartamento(id):
            nombre = input("Nuevo Nombre: ")
            gerente = input("Nuevo ID Gerente: ")
            if self.__ctrlDepartamento.actualizarDepartamentoControl(id, nombre, gerente):
                print("Departamento actualizado con éxito")
        else:
            print("No existe un Departamento con ese ID")

    def verEmpleados(self):
        empleados = self.__ctrlEmpleado.getEmpleados()
        if empleados:
            for e in empleados:
                print("ID:", e.getIdEmpleado())
                print("Nombre:", e.getNombreCompleto())
                print("Correo:", e.getCorreo())
                print("Depto:", e.getIdDepartamento())
        else:
            print("No hay empleados registrados")

    def buscarEmpleado(self):
        id = input("Ingrese el ID del Empleado: ")
        e = self.__ctrlEmpleado.getEmpleado(id)
        if e:
            print("ID:", e.getIdEmpleado())
            print("Nombre:", e.getNombreCompleto())
            print("Correo:", e.getCorreo())
            print("Depto:", e.getIdDepartamento())
        else:
            print("No existe un Empleado con ese ID")

    def agregarEmpleado(self):
        id = input("Ingrese el ID del Empleado: ")
        if not self.__ctrlEmpleado.existeEmpleado(id):
            nombre = input("Ingrese el Nombre: ")
            correo = input("Ingrese el Correo: ")
            depto = input("Ingrese el ID del Departamento: ")
            if self.__ctrlEmpleado.agregarEmpleadoControl(id, nombre, correo, depto):
                print("Empleado agregado con éxito")
        else:
            print("Ya existe un Empleado con ese ID")

    def eliminarEmpleado(self):
        id = input("Ingrese el ID del Empleado: ")
        if self.__ctrlEmpleado.existeEmpleado(id):
            if self.__ctrlEmpleado.eliminarEmpleadoControl(id):
                print("Empleado eliminado con éxito")
        else:
            print("No existe un Empleado con ese ID")

    def actualizarEmpleado(self):
        id = input("Ingrese el ID del Empleado: ")
        if self.__ctrlEmpleado.existeEmpleado(id):
            nombre = input("Nuevo Nombre: ")
            correo = input("Nuevo Correo: ")
            depto = input("Nuevo ID Departamento: ")
            if self.__ctrlEmpleado.actualizarEmpleadoControl(id, nombre, correo, depto):
                print("Empleado actualizado con éxito")
        else:
            print("No existe un Empleado con ese ID")

    def verProyectos(self):
        proyectos = self.__ctrlProyecto.getProyectos()
        if proyectos:
            for p in proyectos:
                print("ID:", p.getIdProyecto())
                print("Nombre:", p.getNombre())
                print("Depto:", p.getIdDepartamento())
        else:
            print("No hay proyectos registrados")

    def buscarProyecto(self):
        id = input("Ingrese el ID del Proyecto: ")
        p = self.__ctrlProyecto.getProyecto(id)
        if p:
            print("ID:", p.getIdProyecto())
            print("Nombre:", p.getNombre())
            print("Depto:", p.getIdDepartamento())
        else:
            print("No existe un Proyecto con ese ID")

    def agregarProyecto(self):
        id = input("Ingrese el ID del Proyecto: ")
        if not self.__ctrlProyecto.existeProyecto(id):
            nombre = input("Ingrese el Nombre: ")
            depto = input("Ingrese el ID del Departamento: ")
            if self.__ctrlProyecto.agregarProyectoControl(id, nombre, depto):
                print("Proyecto agregado con éxito")
        else:
            print("Ya existe un Proyecto con ese ID")

    def eliminarProyecto(self):
        id = input("Ingrese el ID del Proyecto: ")
        if self.__ctrlProyecto.existeProyecto(id):
            if self.__ctrlProyecto.eliminarProyectoControl(id):
                print("Proyecto eliminado con éxito")
        else:
            print("No existe un Proyecto con ese ID")

    def actualizarProyecto(self):
        id = input("Ingrese el ID del Proyecto: ")
        if self.__ctrlProyecto.existeProyecto(id):
            nombre = input("Nuevo Nombre: ")
            depto = input("Nuevo ID Departamento: ")
            if self.__ctrlProyecto.actualizarProyectoControl(id, nombre, depto):
                print("Proyecto actualizado con éxito")
        else:
            print("No existe un Proyecto con ese ID")

    def verRegistros(self):
        registros = self.__ctrlRegistro.getRegistros()
        if registros:
            for r in registros:
                print("ID:", r.getIdRegistro())
                print("Fecha:", r.getFecha())
                print("Horas:", r.getHoras())
                print("Descripción:", r.getDescripcionTarea())
        else:
            print("No hay registros de tiempo")

    def buscarRegistro(self):
        id = input("Ingrese el ID del Registro de Tiempo: ")
        r = self.__ctrlRegistro.getRegistro(id)
        if r:
            print("ID:", r.getIdRegistro())
            print("Fecha:", r.getFecha())
            print("Horas:", r.getHoras())
            print("Descripción:", r.getDescripcionTarea())
        else:
            print("No existe un Registro con ese ID")

    def agregarRegistro(self):
        id = input("Ingrese el ID del Registro: ")
        if not self.__ctrlRegistro.existeRegistro(id):
            fecha = input("Ingrese la Fecha: ")
            horas = input("Ingrese las Horas: ")
            descripcion = input("Ingrese la Descripción: ")
            if self.__ctrlRegistro.agregarRegistroControl(id, fecha, horas, descripcion):
                print("Registro agregado con éxito")
        else:
            print("Ya existe un Registro con ese ID")

    def eliminarRegistro(self):
        id = input("Ingrese el ID del Registro que desea eliminar: ")
        if self.__ctrlRegistro.existeRegistro(id):
            if self.__ctrlRegistro.eliminarRegistroControl(id):
                print("Registro eliminado con éxito")
        else:
            print("No existe un Registro con ese ID")

    def actualizarRegistro(self):
        id = input("Ingrese el ID del Registro que desea actualizar: ")
        if self.__ctrlRegistro.existeRegistro(id):
            fecha = input("Nueva Fecha: ")
            horas = input("Nuevas Horas: ")
            descripcion = input("Nueva Descripción: ")
            if self.__ctrlRegistro.actualizarRegistroControl(id, fecha, horas, descripcion):
                print("Registro actualizado con éxito")
        else:
            print("No existe un Registro con ese ID")

    def menu(self):
        print("=== MENÚ PRINCIPAL ===")
        print("1. Ver Departamentos")
        print("2. Buscar Departamento")
        print("3. Agregar Departamento")
        print("4. Eliminar Departamento")
        print("5. Actualizar Departamento")
        print("6. Ver Empleados")
        print("7. Buscar Empleado")
        print("8. Agregar Empleado")
        print("9. Eliminar Empleado")
        print("10. Actualizar Empleado")
        print("11. Ver Proyectos")
        print("12. Buscar Proyecto")
        print("13. Agregar Proyecto")
        print("14. Eliminar Proyecto")
        print("15. Actualizar Proyecto")
        print("16. Ver Registros de Tiempo")
        print("17. Buscar Registro de Tiempo")
        print("18. Agregar Registro de Tiempo")
        print("19. Eliminar Registro de Tiempo")
        print("20. Actualizar Registro de Tiempo")
        print("21. Salir")

    def cargarMenu(self):
        sigue = True
        while sigue:
            self.menu()
            opc = input("ELIGE UNA OPCIÓN: ")
            if opc == "1": 
                self.verDepartamentos()
            elif opc == "2": 
                self.buscarDepartamento()
            elif opc == "3": 
                self.agregarDepartamento()
            elif opc == "4":
                self.eliminarDepartamento()
            elif opc == "5": 
                self.actualizarDepartamento()
            elif opc == "6": 
                self.verEmpleados()
            elif opc == "7":
                self.buscarEmpleado()
            elif opc == "8": 
                self.agregarEmpleado()
            elif opc == "9": 
                self.eliminarEmpleado()
            elif opc == "10":
                self.actualizarEmpleado()
            elif opc == "11":
                self.verProyectos()
            elif opc == "12": 
                self.buscarProyecto()
            elif opc == "13": 
                self.agregarProyecto()
            elif opc == "14":
                self.eliminarProyecto()
            elif opc == "15": 
                self.actualizarProyecto()
            elif opc == "16":
                self.verRegistros()
            elif opc == "17": 
                self.buscarRegistro()
            elif opc == "18": 
                self.agregarRegistro()
            elif opc == "19":
                self.eliminarRegistro()
            elif opc == "20": 
                self.actualizarRegistro()
            elif opc == "21":
                print("Saliendo del sistema...")
                sigue = False
            else:
                print("Opción inválida...")
            input("Presione ENTER para continuar...")

if __name__ == "__main__":
    interfaz = Interfaz()
    interfaz.cargarMenu()