class EmpleadoDTO:
    def __init__(self, idEmpleado, nombreCompleto, direccion, telefono, correo, fechaContratacion, salario, idDepartamento=None):
        self.__idEmpleado = idEmpleado
        self.__nombreCompleto = nombreCompleto
        self.__direccion = direccion
        self.__telefono = telefono
        self.__correo = correo
        self.__fechaContratacion = fechaContratacion
        self.__salario = salario
        self.__idDepartamento = idDepartamento

    def getIdEmpleado(self):
        return self.__idEmpleado

    def getNombreCompleto(self):
        return self.__nombreCompleto

    def getDireccion(self):
        return self.__direccion

    def getTelefono(self):
        return self.__telefono

    def getCorreo(self):
        return self.__correo

    def getFechaContratacion(self):
        return self.__fechaContratacion

    def getSalario(self):
        return self.__salario

    def getIdDepartamento(self):
        return self.__idDepartamento

    def setIdEmpleado(self, newIdEmpleado):
        self.__idEmpleado = newIdEmpleado
    
    def setNombreCompleto(self, newNombreCompleto):
        self.__nombreCompleto = newNombreCompleto

    def setDireccion(self, newDireccion):
        self.__direccion = newDireccion

    def setTelefono(self, newTelefono):
        self.__telefono = newTelefono

    def setCorreo(self, newCorreo):
        self.__correo = newCorreo

    def setFechaContratacion(self, newFechaContratacion):
        self.__fechaContratacion = newFechaContratacion

    def setSalario(self, newSalario):
        self.__salario = newSalario

    def setIdDepartamento(self, newIdDepartamento):
        self.__idDepartamento = newIdDepartamento


class DepartamentoDTO:
    def __init__(self, idDepartamento, nombre, idGerente=None):
        self.__idDepartamento = idDepartamento
        self.__nombre = nombre
        self.__idGerente = idGerente

    def getIdDepartamento(self):
        return self.__idDepartamento

    def getNombre(self):
        return self.__nombre

    def getIdGerente(self):
        return self.__idGerente

    def setIdDepartamento(self, newIdDepartamento):
        self.__idDepartamento = newIdDepartamento
    
    def setNombre(self, newNombre):
        self.__nombre = newNombre

    def setIdGerente(self, newIdGerente):
        self.__idGerente = newIdGerente


class ProyectoDTO:
    def __init__(self, idProyecto, nombre, descripcion, fechaInicio, idDepartamento=None):
        self.__idProyecto = idProyecto
        self.__nombre = nombre
        self.__descripcion = descripcion
        self.__fechaInicio = fechaInicio
        self.__idDepartamento = idDepartamento

    def getIdProyecto(self):
        return self.__idProyecto

    def getNombre(self):
        return self.__nombre

    def getDescripcion(self):
        return self.__descripcion

    def getFechaInicio(self):
        return self.__fechaInicio

    def getIdDepartamento(self):
        return self.__idDepartamento

    def setIdProyecto(self, newIdProyecto):
        self.__idProyecto = newIdProyecto
    
    def setNombre(self, newNombre):
        self.__nombre = newNombre

    def setDescripcion(self, newDescripcion):
        self.__descripcion = newDescripcion

    def setFechaInicio(self, newFechaInicio):
        self.__fechaInicio = newFechaInicio

    def setIdDepartamento(self, newIdDepartamento):
        self.__idDepartamento = newIdDepartamento


class RegistroTiempoDTO:
    def __init__(self, idRegistro, fecha, horas, descripcionTarea):
        self.__idRegistro = idRegistro
        self.__fecha = fecha
        self.__horas = horas
        self.__descripcionTarea = descripcionTarea

    def getIdRegistro(self):
        return self.__idRegistro

    def getFecha(self):
        return self.__fecha

    def getHoras(self):
        return self.__horas
    
    def getDescripcionTarea(self):
        return self.__descripcionTarea

    def setIdRegistro(self, newIdRegistro):
        self.__idRegistro = newIdRegistro

    def setFecha(self, newFecha):
        self.__fecha = newFecha

    def setHoras(self, newHoras):
        self.__horas = newHoras

    def setDescripcionTarea(self, newDescripcionTarea):
        self.__descripcionTarea = newDescripcionTarea