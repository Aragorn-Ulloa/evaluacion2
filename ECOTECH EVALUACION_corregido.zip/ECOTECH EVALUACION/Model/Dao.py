import pymysql
import sys
sys.path.append("C:/Users/Panmpe/ECOTECH EVALUACION")
from Model.Dto import DepartamentoDTO, EmpleadoDTO, ProyectoDTO, RegistroTiempoDTO

class BaseDAO:
    def __init__(self, host="localhost", user="root", password="", database="ecotech_db"):
        self.host = host
        self.user = user
        self.password = password
        self.database = database

    def obtenerConexion(self):
        try:
            conexion = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database
            )
            return conexion
        except pymysql.MySQLError as e:
            print("Error al conectar a la base de datos:", e)
            return None

class DepartamentoDAO(BaseDAO):
    def verDepartamentos(self):
        lista = []
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_departamento, nombre, id_gerente FROM departamento")
                for fila in cursor.fetchall():
                    lista.append((fila[0], fila[1], fila[2]))
                cursor.close()
                conexion.close()
            except pymysql.MySQLError as e:
                print("Error:", e)
        return lista

    def buscarDepartamento(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_departamento, nombre, id_gerente FROM departamento WHERE id_departamento=%s", (id,))
                fila = cursor.fetchone()
                cursor.close()
                conexion.close()
                return fila
            except pymysql.MySQLError as e:
                print("Error:", e)
        return None

    def agregarDepartamento(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO departamento (id_departamento, nombre, id_gerente) VALUES (%s,%s,%s)",
                               (dto.getIdDepartamento(), dto.getNombre(), dto.getIdGerente()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def eliminarDepartamento(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM departamento WHERE id_departamento=%s", (id,))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def actualizarDepartamento(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("UPDATE departamento SET nombre=%s, id_gerente=%s WHERE id_departamento=%s",
                               (dto.getNombre(), dto.getIdGerente(), dto.getIdDepartamento()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

class EmpleadoDAO(BaseDAO):
    def verEmpleados(self):
        lista = []
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_empleado, nombre, correo, id_departamento FROM empleado")
                for fila in cursor.fetchall():
                    lista.append((fila[0], fila[1], fila[2], fila[3]))
                cursor.close()
                conexion.close()
            except pymysql.MySQLError as e:
                print("Error:", e)
        return lista

    def buscarEmpleado(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_empleado, nombre, correo, id_departamento FROM empleado WHERE id_empleado=%s", (id,))
                fila = cursor.fetchone()
                cursor.close()
                conexion.close()
                return fila
            except pymysql.MySQLError as e:
                print("Error:", e)
        return None

    def agregarEmpleado(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO empleado (id_empleado, nombre, correo, id_departamento) VALUES (%s,%s,%s,%s)",
                               (dto.getIdEmpleado(), dto.getNombre(), dto.getCorreo(), dto.getIdDepartamento()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def eliminarEmpleado(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM empleado WHERE id_empleado=%s", (id,))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def actualizarEmpleado(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("UPDATE empleado SET nombre=%s, correo=%s, id_departamento=%s WHERE id_empleado=%s",
                               (dto.getNombre(), dto.getCorreo(), dto.getIdDepartamento(), dto.getIdEmpleado()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

class ProyectoDAO(BaseDAO):
    def verProyectos(self):
        lista = []
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_proyecto, nombre, id_departamento FROM proyecto")
                for fila in cursor.fetchall():
                    lista.append((fila[0], fila[1], fila[2]))
                cursor.close()
                conexion.close()
            except pymysql.MySQLError as e:
                print("Error:", e)
        return lista

    def buscarProyecto(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_proyecto, nombre, id_departamento FROM proyecto WHERE id_proyecto=%s", (id,))
                fila = cursor.fetchone()
                cursor.close()
                conexion.close()
                return fila
            except pymysql.MySQLError as e:
                print("Error:", e)
        return None

    def agregarProyecto(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO proyecto (id_proyecto, nombre, id_departamento) VALUES (%s,%s,%s)",
                               (dto.getIdProyecto(), dto.getNombre(), dto.getIdDepartamento()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def eliminarProyecto(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM proyecto WHERE id_proyecto=%s", (id,))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def actualizarProyecto(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("UPDATE proyecto SET nombre=%s, id_departamento=%s WHERE id_proyecto=%s",
                               (dto.getNombre(), dto.getIdDepartamento(), dto.getIdProyecto()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

class RegistroTiempoDAO(BaseDAO):
    def verRegistros(self):
        lista = []
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_registro, fecha, horas, descripcion FROM registro_tiempo")
                for fila in cursor.fetchall():
                    lista.append((fila[0], fila[1], fila[2], fila[3]))
                cursor.close()
                conexion.close()
            except pymysql.MySQLError as e:
                print("Error:", e)
        return lista

    def buscarRegistro(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_registro, fecha, horas, descripcion FROM registro_tiempo WHERE id_registro=%s", (id,))
                fila = cursor.fetchone()
                cursor.close()
                conexion.close()
                return fila
            except pymysql.MySQLError as e:
                print("Error:", e)
        return None

    def agregarRegistro(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("INSERT INTO registro_tiempo (id_registro, fecha, horas, descripcion) VALUES (%s,%s,%s,%s)",
                               (dto.getIdRegistro(), dto.getFecha(), dto.getHoras(), dto.getDescripcionTarea()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def eliminarRegistro(self, id):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM registro_tiempo WHERE id_registro=%s", (id,))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False

    def actualizarRegistro(self, dto):
        conexion = self.obtenerConexion()
        if conexion:
            try:
                cursor = conexion.cursor()
                cursor.execute("UPDATE registro_tiempo SET fecha=%s, horas=%s, descripcion=%s WHERE id_registro=%s",
                               (dto.getFecha(), dto.getHoras(), dto.getDescripcionTarea(), dto.getIdRegistro()))
                conexion.commit()
                cursor.close()
                conexion.close()
                return True
            except pymysql.MySQLError as e:
                print("Error:", e)
        return False
