from os import system
from datetime import datetime
from decimal import Decimal, InvalidOperation #funcion sugerida por IA para validar el ingreso de horas con decimales
from control.controlGestor import ControlDepartamento, ControlEmpleado, ControlProyecto, ControlRegistroTiempo

class Interfaz:
    def __init__(self):
        self.__ctrlDepartamento = ControlDepartamento()
        self.__ctrlEmpleado = ControlEmpleado()
        self.__ctrlProyecto = ControlProyecto()
        self.__ctrlRegistro = ControlRegistroTiempo()

    def verDepartamentos(self):
        system("cls")  
        departamentos = self.__ctrlDepartamento.getDepartamentos()
        if departamentos:
            for obj in departamentos:
                print()
                print("ID     :", obj.getIdDepartamento())
                print("Nombre :", obj.getNombre())
                print("Gerente:", obj.getIdGerente())
                print()
        else:
            print("No hay departamentos registrados")

    def buscarDepartamento(self):
        system("cls")
        id = input("Ingrese el ID del departamento: ")
        depto = self.__ctrlDepartamento.getDepartamento(id)
        if depto:
            print("ID     :", depto.getIdDepartamento())
            print("Nombre :", depto.getNombre())
            print("Gerente:", depto.getIdGerente())
        else:
            print("no existe un Departamento con ese ID")

    def agregarDepartamento(self):
        system("cls")
        id = input("Ingrese el ID del departamento: ")
        if not self.__ctrlDepartamento.existeDepartamento(id):
            nombre = input("Ingrese el nombre: ")
            gerente = input("Ingrese el ID del gerente: ")
            if gerente == "":
                gerente = None
            if self.__ctrlDepartamento.agregarDepartamentoControl(id, nombre, gerente):
                print("Departamento agregado con exito!")
            else:
                print("No se pudo agregar el departamento")
        else:
            print("Ya existe un departamento con ese ID")

    def eliminarDepartamento(self):
        system("cls")
        id = input("Ingrese el ID del departamento: ")
        if self.__ctrlDepartamento.existeDepartamento(id):
            if self.__ctrlDepartamento.eliminarDepartamentoControl(id):
                print("Departamento eliminado con éxito")
            else:
                print("No se pudo eliminar el departamento")
        else:
            print("No existe un Departamento con ese ID")

    def actualizarDepartamento(self):
        system("cls")
        id = input("Ingrese el ID del departamento: ")
        if self.__ctrlDepartamento.existeDepartamento(id):
            nombre = input("Nuevo nombre: ")
            gerente = input("Nuevo ID gerente: ")
            if gerente == "":
                gerente = None
            if self.__ctrlDepartamento.actualizarDepartamentoControl(id, nombre, gerente):
                print("departamento actualizado con éxito")
            else:
                print("No se pudo actualizar el departamento")
        else:
            print("No existe un departamento con ese ID")

    def verEmpleados(self):
        system("cls")
        empleados = self.__ctrlEmpleado.getEmpleados()
        if empleados:
            for obj in empleados:
                print()
                print("ID    :", obj.getIdEmpleado())
                print("Nombre:", obj.getNombreCompleto())
                print("Correo:", obj.getCorreo())
                print("Depto :", obj.getIdDepartamento())
                print()
        else:
            print("No hay empleados registrados")

    def buscarEmpleado(self):
        system("cls")
        id = input("Ingrese el ID del empleado: ")
        empleado = self.__ctrlEmpleado.getEmpleado(id)
        if empleado:
            print("ID    :", empleado.getIdEmpleado())
            print("Nombre:", empleado.getNombreCompleto())
            print("Correo:", empleado.getCorreo())
            print("Depto :", empleado.getIdDepartamento())
        else:
            print("No existe un empleado con ese ID")

    def agregarEmpleado(self):
        system("cls")
        id = input("Ingrese el ID del empleado: ")
        if not self.__ctrlEmpleado.existeEmpleado(id):
            nombre = input("Ingrese el nombre: ")
            correo = input("Ingrese el correo: ")
            depto = input("Ingrese el ID del departamento: ")
            if self.__ctrlDepartamento.existeDepartamento(depto):
                if self.__ctrlEmpleado.agregarEmpleadoControl(id, nombre, correo, depto):
                    print("Empleado agregado con exito")
                else:
                    print("No se pudo agregar el empleado")
            else:
                print("No existe un departamento con ese ID")
        else:
            print("Ya existe un empleado con ese ID")

    def eliminarEmpleado(self):
        system("cls")
        id = input("Ingrese el ID del empleado: ")
        if self.__ctrlEmpleado.existeEmpleado(id):
            if self.__ctrlEmpleado.eliminarEmpleadoControl(id):
                print("Empleado eliminado con exito")
            else:
                print("No se pudo eliminar el empleado")
        else:
            print("No existe un empleado con ese ID")

    def actualizarEmpleado(self):
        system("cls")
        id = input("Ingrese el ID del empleado: ")
        if self.__ctrlEmpleado.existeEmpleado(id):
            nombre = input("Nuevo nombre: ")
            correo = input("Nuevo correo: ")
            depto = input("Nuevo ID departamento: ")
            if self.__ctrlDepartamento.existeDepartamento(depto):
                if self.__ctrlEmpleado.actualizarEmpleadoControl(id, nombre, correo, depto):
                    print("Empleado actualizado con exito")
                else:
                    print("No se pudo actualizar el empleado")
            else:
                print("No existe un departamento con ese ID")
        else:
            print("No existe un empleado con ese ID")

    def verProyectos(self):
        system("cls")
        proyectos = self.__ctrlProyecto.getProyectos()
        if proyectos:
            for obj in proyectos:
                print()
                print("ID    :", obj.getIdProyecto())
                print("Nombre:", obj.getNombre())
                print("Depto :", obj.getIdDepartamento())
                print()
        else:
            print("No hay proyectos registrados")

    def buscarProyecto(self):
        system("cls")
        id = input("Ingrese el ID del proyecto: ")
        proyecto = self.__ctrlProyecto.getProyecto(id)
        if proyecto:
            print("ID    :", proyecto.getIdProyecto())
            print("Nombre:", proyecto.getNombre())
            print("Depto :", proyecto.getIdDepartamento())
        else:
            print("No existe un proyecto con ese ID")

    def agregarProyecto(self):
        system("cls")
        id = input("Ingrese el ID del proyecto: ")
        if not self.__ctrlProyecto.existeProyecto(id):
            nombre = input("Ingrese el nombre: ")
            depto = input("Ingrese el ID del departamento: ")
            if self.__ctrlDepartamento.existeDepartamento(depto):
                if self.__ctrlProyecto.agregarProyectoControl(id, nombre, depto):
                    print("Proyecto agregado con exito")
                else:
                    print("No se pudo agregar el proyecto")
            else:
                print("No existe un departamento con ese ID")
        else:
            print("Ya existe un proyecto con ese ID")

    def eliminarProyecto(self):
        system("cls")
        id = input("Ingrese el ID del proyecto: ")
        if self.__ctrlProyecto.existeProyecto(id):
            if self.__ctrlProyecto.eliminarProyectoControl(id):
                print("Proyecto eliminado con exito")
            else:
                print("No se pudo eliminar el proyecto")
        else:
            print("No existe un proyecto con ese ID")

    def actualizarProyecto(self):
        system("cls")
        id = input("Ingrese el ID del proyecto: ")
        if self.__ctrlProyecto.existeProyecto(id):
            nombre = input("Nuevo nombre: ")
            depto = input("Nuevo ID departamento: ")
            if self.__ctrlDepartamento.existeDepartamento(depto):
                if self.__ctrlProyecto.actualizarProyectoControl(id, nombre, depto):
                    print("Proyecto actualizado con exito")
                else:
                    print("No se pudo actualizar el proyecto")
            else:
                print("No existe un departamento con ese ID")
        else:
            print("No existe un proyecto con ese ID")

    def verRegistros(self):
        system("cls")
        registros = self.__ctrlRegistro.getRegistros()
        if registros:
            for obj in registros:
                print()
                print("ID         :", obj.getIdRegistro())
                print("Fecha      :", obj.getFecha())
                print("Horas      :", obj.getHoras())
                print("Descripción:", obj.getDescripcionTarea())
                print()
        else:
            print("No hay registros de tiempo")

    def buscarRegistro(self):
        system("cls")
        id = input("Ingrese el ID del registro de tiempo: ")
        registro = self.__ctrlRegistro.getRegistro(id)
        if registro:
            print("ID         :", registro.getIdRegistro())
            print("Fecha      :", registro.getFecha())
            print("Horas      :", registro.getHoras())
            print("Descripción:", registro.getDescripcionTarea())
        else:
            print("No existe un registro con ese ID")

    def agregarRegistro(self):
        system("cls")
        id = input("Ingrese el ID del registro: ")
        try:
            int(id)
        except ValueError:
            print("El ID del registro debe ser un numero entero")
            return

        if not self.__ctrlRegistro.existeRegistro(id):
            fecha = input("Ingrese la fecha (AAAA-MM-DD): ")
            horas = input("Ingrese las horas: ")
            descripcion = input("Ingrese la descripcion: ")
            try:
                datetime.strptime(fecha, "%Y-%m-%d")
                horas = Decimal(horas)
                if not horas.is_finite() or abs(horas) > Decimal("999.99") or horas.as_tuple().exponent < -2:
                    print("Las horas deben ser un numero con solo dos decimales")
                    return
            except (ValueError, InvalidOperation):
                print("Ingrese una fecha valida (AAAA-MM-DD) y horas numericas")
                return

            if self.__ctrlRegistro.agregarRegistroControl(id, fecha, horas, descripcion):
                print("Registro agregado con exito")
            else:
                print("No se pudo agregar el registro de tiempo")
        else:
            print("Ya existe un registro con ese ID")

    def eliminarRegistro(self):
        system("cls")
        id = input("Ingrese el ID del registro que desea eliminar: ")
        if self.__ctrlRegistro.existeRegistro(id):
            if self.__ctrlRegistro.eliminarRegistroControl(id):
                print("Registro eliminado con éxito")
            else:
                print("No se pudo eliminar el registro de tiempo")
        else:
            print("No existe un registro con ese ID")

    def actualizarRegistro(self):
        system("cls")
        id = input("Ingrese el ID del registro que desea actualizar: ")
        try:
            int(id)
        except ValueError:
            print("El ID del registro debe ser un numero entero")
            return

        if self.__ctrlRegistro.existeRegistro(id):
            fecha = input("Nueva fecha (AAAA-MM-DD): ")
            horas = input("Nuevas horas: ")
            descripcion = input("Nueva descripción: ")
            try:
                datetime.strptime(fecha, "%Y-%m-%d")
                horas = Decimal(horas)
                if not horas.is_finite() or abs(horas) > Decimal("999.99") or horas.as_tuple().exponent < -2:
                    print("Las horas deben ser un numero con solo dos decimales")
                    return
            except (ValueError, InvalidOperation):
                print("Ingrese una fecha valida (AAAA-MM-DD) y horas numericas")
                return

            if self.__ctrlRegistro.actualizarRegistroControl(id, fecha, horas, descripcion):
                print("Registro actualizado con exito")
            else:
                print("No se pudo actualizar el registro de tiempo")
        else:
            print("No existe un registro con ese ID")

    def menu(self):
        system("cls")
        print("---MENU-PRINCIPAL---")
        print("1- Ver departamentos")
        print("2- Buscar departamento")
        print("3- Agregar departamento")
        print("4- Eliminar departamento")
        print("5- Actualizar departamento")
        print("6- Ver empleados")
        print("7- Buscar empleado")
        print("8- Agregar empleado")
        print("9- Eliminar empleado")
        print("10- Actualizar empleado")
        print("11- Ver proyectos")
        print("12- Buscar proyecto")
        print("13- Agregar proyecto")
        print("14- Eliminar proyecto")
        print("15- Actualizar proyecto")
        print("16- Ver registros de tiempo")
        print("17- Buscar registro de tiempo")
        print("18- Agregar registro de tiempo")
        print("19- Eliminar registro de tiempo")
        print("20- Actualizar registro de tiempo")
        print("21- Salir")

    def cargarMenu(self):
        sigue = True
        while sigue:
            self.menu()
            opc = input("ESCOJA UNA OPCION: ")
            if opc == "1": 
                self.verDepartamentos()
            elif opc == "2": 
                self.buscarDepartamento()
            elif opc == "3": 
                self.agregarDepartamento()
            elif opc == "4":
                self.eliminarDepartamento()
            elif opc == "5": 
                self.actualizarDepartamento()
            elif opc == "6": 
                self.verEmpleados()
            elif opc == "7":
                self.buscarEmpleado()
            elif opc == "8": 
                self.agregarEmpleado()
            elif opc == "9": 
                self.eliminarEmpleado()
            elif opc == "10":
                self.actualizarEmpleado()
            elif opc == "11":
                self.verProyectos()
            elif opc == "12": 
                self.buscarProyecto()
            elif opc == "13": 
                self.agregarProyecto()
            elif opc == "14":
                self.eliminarProyecto()
            elif opc == "15": 
                self.actualizarProyecto()
            elif opc == "16":
                self.verRegistros()
            elif opc == "17": 
                self.buscarRegistro()
            elif opc == "18": 
                self.agregarRegistro()
            elif opc == "19":
                self.eliminarRegistro()
            elif opc == "20": 
                self.actualizarRegistro()
            elif opc == "21":
                print("Saliendo del sistema...")
                sigue = False
            else:
                print("Opción invalida...")
            input("Presione ENTER para continuar...")

if __name__ == "__main__":
    interfaz = Interfaz()
    interfaz.cargarMenu()