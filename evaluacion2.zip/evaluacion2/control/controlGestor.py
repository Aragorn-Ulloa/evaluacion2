from model.Dao import DepartamentoDAO, EmpleadoDAO, ProyectoDAO, RegistroTiempoDAO
from model.Dto import DepartamentoDTO, EmpleadoDTO, ProyectoDTO, RegistroTiempoDTO

class ControlDepartamento:
    def __init__(self):
        self.__dao = DepartamentoDAO()

    #obtiene todos los departamentos y los convierte a objetos
    def getDepartamentos(self):
        departamentos = []
        depTpl = self.__dao.verDepartamentos()
        if depTpl:
            for obj in depTpl:
                departamentos.append(DepartamentoDTO(obj[0], obj[1], obj[2]))
        return departamentos

    #busca un departamento específico por su ID
    def getDepartamento(self, id):
        obj = self.__dao.buscarDepartamento(id)
        if obj:
            return DepartamentoDTO(obj[0], obj[1], obj[2])
        return None  

    #agrega un nuevo departamento a la base de datos
    def agregarDepartamentoControl(self, id, nombre, idGerente):
        dto = DepartamentoDTO(id, nombre, idGerente)
        return self.__dao.agregarDepartamento(dto)

    #elimina un departamento por su ID
    def eliminarDepartamentoControl(self, id):
        return self.__dao.eliminarDepartamento(id)

    #actualiza los datos de un departamento existente
    def actualizarDepartamentoControl(self, id, nombre, idGerente):
        dto = DepartamentoDTO(id, nombre, idGerente)
        return self.__dao.actualizarDepartamento(dto)

    #verifica si un departamento existe en la base de datos
    def existeDepartamento(self, id):
        return self.__dao.buscarDepartamento(id) is not None

#clase controladora para gestionar la lógica de empleados
class ControlEmpleado:
    def __init__(self):
        self.__dao = EmpleadoDAO()

    #obtiene todos los empleados
    def getEmpleados(self):
        empleados = []
        emplTpl = self.__dao.verEmpleados()
        if emplTpl:
            for obj in emplTpl:
                empleados.append(EmpleadoDTO(obj[0], obj[1], "", "", obj[2], "", 0.0, obj[3]))
        return empleados

    #busca un empleado específico por su ID
    def getEmpleado(self, id):
        obj = self.__dao.buscarEmpleado(id)
        if obj:
            return EmpleadoDTO(obj[0], obj[1], "", "", obj[2], "", 0.0, obj[3])
        return None

    #agrega un nuevo empleado a la base de datos
    def agregarEmpleadoControl(self, id, nombre, correo, idDepto):
        dto = EmpleadoDTO(id, nombre, "", "", correo, "", 0.0, idDepto)
        return self.__dao.agregarEmpleado(dto)

    #elimina un empleado por su ID
    def eliminarEmpleadoControl(self, id):
        return self.__dao.eliminarEmpleado(id)

    #actualiza los datos de un empleado existente
    def actualizarEmpleadoControl(self, id, nombre, correo, idDepto):
        # Crea DTO con los nuevos datos y valores por defecto
        dto = EmpleadoDTO(id, nombre, "", "", correo, "", 0.0, idDepto)
        return self.__dao.actualizarEmpleado(dto)

    #verifica si un empleado existe en la base de datos
    def existeEmpleado(self, id):
        return self.__dao.buscarEmpleado(id) is not None


#clase controladora para gestionar los proyectos
class ControlProyecto:
    def __init__(self):
        self.__dao = ProyectoDAO()

    #obtiene todos los proyectos 
    def getProyectos(self):
        proyectos = []
        proyectTpl = self.__dao.verProyectos()
        if proyectTpl:
            for obj in proyectTpl:
                proyectos.append(ProyectoDTO(obj[0], obj[1], "", "", obj[2]))
        return proyectos

    #busca un proyecto específico por su ID
    def getProyecto(self, id):
        obj = self.__dao.buscarProyecto(id)
        if obj:
            # Retorna el DTO si se encuentra el proyecto
            return ProyectoDTO(obj[0], obj[1], "", "", obj[2])
        return None  # Retorna None si no existe

    #agrega un nuevo proyecto a la base de datos
    def agregarProyectoControl(self, id, nombre, idDepto):
        # Crea DTO con datos proporcionados y valores por defecto
        dto = ProyectoDTO(id, nombre, "", "", idDepto)
        return self.__dao.agregarProyecto(dto)

    #elimina un proyecto por su ID
    def eliminarProyectoControl(self, id):
        return self.__dao.eliminarProyecto(id)

    #actualiza los datos de un proyecto existente
    def actualizarProyectoControl(self, id, nombre, idDepto):
        # Crea DTO con los nuevos datos y valores por defecto
        dto = ProyectoDTO(id, nombre, "", "", idDepto)
        return self.__dao.actualizarProyecto(dto)

    #verifica si un proyecto existe en la base de datos
    def existeProyecto(self, id):
        return self.__dao.buscarProyecto(id) is not None

#clase controladora para gestionar registros de tiempo
class ControlRegistroTiempo:
    def __init__(self):
        self.__dao = RegistroTiempoDAO()

    #obtiene todos los registros de tiempo
    def getRegistros(self):
        registros = []
        registrosTpl = self.__dao.verRegistros()
        if registrosTpl:
            for obj in registrosTpl:
                registros.append(RegistroTiempoDTO(obj[0], obj[1], obj[2], obj[3]))
        return registros

    #busca un registro de tiempo por su ID
    def getRegistro(self, id):
        obj = self.__dao.buscarRegistro(id)
        if obj:

            return RegistroTiempoDTO(obj[0], obj[1], obj[2], obj[3])
        return None

    #agrega un nuevo registro de tiempo a la base de datos
    def agregarRegistroControl(self, id, fecha, horas, descripcion):

        dto = RegistroTiempoDTO(id, fecha, horas, descripcion)
        return self.__dao.agregarRegistro(dto)

    #elimina un registro de tiempo por su ID
    def eliminarRegistroControl(self, id):
        return self.__dao.eliminarRegistro(id)

    #actualiza los datos de un registro de tiempo existente
    def actualizarRegistroControl(self, id, fecha, horas, descripcion):
        dto = RegistroTiempoDTO(id, fecha, horas, descripcion)
        return self.__dao.actualizarRegistro(dto)

    #verifica si un registro de tiempo existe en la base de datos
    def existeRegistro(self, id):
        return self.__dao.buscarRegistro(id) is not None