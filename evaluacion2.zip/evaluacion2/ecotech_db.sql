--base de datos hecha con apoyo de IA
-- ============================================
-- SCRIPT DE CREACIÓN DE BASE DE DATOS ECOTECH
-- ============================================

-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS ecotech_db;
USE ecotech_db;

-- ============================================
-- TABLA: DEPARTAMENTO
-- ============================================
CREATE TABLE departamento (
    id_departamento INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    id_gerente INT
);

-- ============================================
-- TABLA: EMPLEADO
-- ============================================
CREATE TABLE empleado (
    id_empleado INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(150),
    id_departamento INT,
    FOREIGN KEY (id_departamento) REFERENCES departamento(id_departamento)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- ============================================
-- TABLA: PROYECTO
-- ============================================
CREATE TABLE proyecto (
    id_proyecto INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    id_departamento INT,
    FOREIGN KEY (id_departamento) REFERENCES departamento(id_departamento)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- ============================================
-- TABLA: REGISTRO_TIEMPO
-- ============================================
CREATE TABLE registro_tiempo (
    id_registro INT PRIMARY KEY,
    fecha DATE NOT NULL,
    horas DECIMAL(5,2) NOT NULL,
    descripcion TEXT
);

-- ============================================
-- DATOS DE PRUEBA
-- ============================================

-- Insertar departamentos
INSERT INTO departamento (id_departamento, nombre, id_gerente) VALUES
(1, 'Desarrollo de Software', 101),
(2, 'Ciberseguridad', 102),
(3, 'Infraestructura TI', 103),
(4, 'Soporte Técnico', NULL);

-- Insertar empleados
INSERT INTO empleado (id_empleado, nombre, correo, id_departamento) VALUES
(101, 'Carlos Rodríguez', 'carlos.rodriguez@ecotech.com', 1),
(102, 'Ana Martínez', 'ana.martinez@ecotech.com', 2),
(103, 'Luis Fernández', 'luis.fernandez@ecotech.com', 3),
(104, 'María López', 'maria.lopez@ecotech.com', 1),
(105, 'Pedro Sánchez', 'pedro.sanchez@ecotech.com', 2),
(106, 'Laura García', 'laura.garcia@ecotech.com', 4),
(107, 'Jorge Ramírez', 'jorge.ramirez@ecotech.com', 1),
(108, 'Sofía Torres', 'sofia.torres@ecotech.com', 3);

-- Insertar proyectos
INSERT INTO proyecto (id_proyecto, nombre, id_departamento) VALUES
(201, 'Sistema de Gestión ECOTECH', 1),
(202, 'Auditoría de Seguridad', 2),
(203, 'Migración a la Nube', 3),
(204, 'Portal Web Corporativo', 1),
(205, 'Implementación Firewall', 2);

-- Insertar registros de tiempo
INSERT INTO registro_tiempo (id_registro, fecha, horas, descripcion) VALUES
(301, '2026-10-13', 8.5, 'Desarrollo de módulo de autenticación'),
(302, '2026-10-13', 6.0, 'Revisión de vulnerabilidades en servidor'),
(303, '2026-10-14', 7.5, 'Configuración de servidores AWS'),
(304, '2026-10-14', 4.0, 'Soporte técnico a usuarios'),
(305, '2026-10-15', 9.0, 'Testing de integración del sistema'),
(306, '2026-10-15', 5.5, 'Análisis de logs de seguridad'),
(307, '2026-10-16', 8.0, 'Desarrollo de API REST'),
(308, '2026-10-16', 7.0, 'Actualización de infraestructura de red');

